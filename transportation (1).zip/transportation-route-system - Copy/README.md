# Sistem Rekomendasi Rute Transportasi

## Deskripsi Proyek
Sistem rekomendasi rute transportasi berbasis preferensi pengguna yang diimplementasikan menggunakan C++ dengan struktur data Graph dan Tree serta prinsip Object-Oriented Programming (OOP).

## Fitur Utama

### 1. Representasi Graf Rute (12 poin)
- Implementasi graf berbobot menggunakan adjacency list
- Memodelkan lokasi sebagai node dan koneksi sebagai edge
- Bobot meliputi jarak (km), waktu (menit), dan biaya (Rp)

### 2. Algoritma Pencarian Rute Terbaik - Dijkstra (15 poin)
- Implementasi algoritma Dijkstra untuk shortest path
- Mendukung optimasi berdasarkan:
  - Jarak terpendek
  - Waktu tercepat
  - Biaya termurah
  - Multi-kriteria dengan bobot custom

### 3. Desain Berorientasi Objek (12 poin)
- **Encapsulation**: Data dan method dikapsulasi dalam kelas
- **Inheritance**: Struktur hierarki kelas yang jelas
- **Polymorphism**: Method virtual dan overriding
- **Abstraction**: Interface yang jelas untuk setiap komponen

### 4. Estimasi Waktu Tempuh & Biaya (10 poin)
- Kalkulasi otomatis total jarak, waktu, dan biaya
- Estimasi berdasarkan data bobot dari graf

### 5. Preferensi Dinamis Pengguna (15 poin)
- **Decision Tree**: Sistem rekomendasi berbasis pertanyaan
- **Multi-kriteria**: Bobot custom untuk setiap kriteria
- Interface interaktif untuk pengaturan preferensi

### 6. CRUD Lokasi & Rute (10 poin)
- Create: Tambah lokasi dan rute baru
- Read: Tampilkan graf dan informasi rute
- Update: Modifikasi data lokasi dan rute
- Delete: Hapus lokasi dan rute

### 7. Simulasi Perjalanan (6 poin)
- Output step-by-step perjalanan
- Informasi detail setiap segmen rute
- Total waktu dan biaya perjalanan

### 8. Struktur Data Tambahan (6 poin)
- **Priority Queue**: Untuk algoritma Dijkstra
- **Unordered Map**: Manajemen node dan data
- **Vector**: Penyimpanan path dan edges
- **Map**: Manajemen bobot dan preferensi

### 9. Visualisasi Teks (7 poin)
- Tampilan graf dalam format teks
- Visualisasi Decision Tree
- Output yang mudah dipahami

### 10. Input/Output File (7 poin)
- Simpan data ke file teks
- Muat data dari file eksternal
- Format data yang terstruktur

## Struktur Kelas

\`\`\`cpp
TransportationSystem (Main Class)
├── Graph
│   ├── Node (Lokasi)
│   └── Edge (Rute)
├── UserPreferences
│   └── DecisionTree
│       └── DecisionTreeNode
└── RouteResult
\`\`\`

## Cara Kompilasi dan Menjalankan

\`\`\`bash
# Kompilasi
make

# Atau manual
g++ -std=c++17 -Wall -Wextra -O2 -o transportation_system main.cpp TransportationSystem.cpp

# Menjalankan
./transportation_system
\`\`\`

## Menu Sistem

1. **Tampilkan Graf Lokasi** - Lihat semua lokasi dan rute
2. **Tambah Lokasi** - Menambah lokasi baru
3. **Tambah Rute** - Menambah rute antar lokasi
4. **Hapus Lokasi** - Menghapus lokasi dan semua rutenya
5. **Hapus Rute** - Menghapus rute spesifik
6. **Cari Rute Terbaik** - Pencarian rute optimal
7. **Set Preferensi Pengguna** - Atur kriteria optimasi
8. **Simulasi Perjalanan** - Simulasi step-by-step
9. **Simpan Data ke File** - Export data
10. **Muat Data dari File** - Import data
11. **Tampilkan Decision Tree** - Lihat struktur decision tree

## Data Default

Sistem dilengkapi dengan data default kota-kota di Indonesia:
- Jakarta, Bandung, Surabaya, Yogyakarta, Semarang, Malang, Solo, Cirebon
- Rute antar kota dengan data realistis jarak, waktu, dan biaya

## Algoritma dan Kompleksitas

- **Dijkstra Algorithm**: O((V + E) log V) dengan priority queue
- **Graph Representation**: Adjacency list untuk efisiensi memori
- **Decision Tree**: O(log n) untuk pencarian preferensi

## Teknologi yang Digunakan

- **Bahasa**: C++17
- **Struktur Data**: Graph (Adjacency List), Tree, Priority Queue, Map
- **Paradigma**: Object-Oriented Programming
- **File I/O**: Text-based storage format

## Contoh Penggunaan

\`\`\`cpp
// Inisialisasi sistem
TransportationSystem system;
system.initializeDefaultData();

// Tambah lokasi baru
system.addLocation("Bali");

// Tambah rute
system.addRoute("Surabaya", "Bali", 350, 420, 150000);

// Set preferensi
system.setUserPreferences();

// Cari rute terbaik
system.findBestRoute("Jakarta", "Bali");

// Simulasi perjalanan
system.simulateJourney("Jakarta", "Bali");
\`\`\`

## Penilaian

Total skor maksimal: 100 poin
- Implementasi Sistem & Dokumentasi: 50%
- Pemahaman (Tanya Jawab): 30%
- Demo Video: 20%

## Tim Pengembang

[Nama Anggota Kelompok]
- Anggota 1: [Nama] - [NRP]
- Anggota 2: [Nama] - [NRP]
- Anggota 3: [Nama] - [NRP]
- Anggota 4: [Nama] - [NRP]
- Anggota 5: [Nama] - [NRP]

## Lisensi

Proyek ini dibuat untuk keperluan akademis - Final Project ET234203 Struktur Data dan Pemrograman Berorientasi Objek.
